<?php

namespace App\Traits;

use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use App\Models\Collections;
use App\Models\User;
use Illuminate\Support\Str; // For slug generation
trait GetRelationalFieldDetail
 {

    /**
    * Validate the request data using dynamically generated rules.
    *
    * @param array $data
    * @param array $predefinedRules
    * @return array
    */

    private function getRelationalFieldDetail($tableName, $id )
        {
        // Default return structure
        $GetData = [ 'id' => $id, 'display' => $id ];
        // Default 'display' is the ID
        $allRelatedData = [];
        // Array to hold all the related data

        try {
            if ( $tableName == 'users' ) {
                $tableName = $tableName;
            } else {
                $tableName = $tableName . '_meta';
            }

            // Check if table exists in the database
            if ( !Schema::hasTable( $tableName ) ) {
                \Log::error( "Table does not exist: $tableName" );
                return $GetData;
                // Return default if table doesn't exist
             }    
             // Fetch all entries for dropdown options
             $entries = \DB::table($tableName)->get();
             // Process all options to keep only id and display fields
             foreach ($entries as $entry) {
                 $entry = (array) $entry; // Convert to array
                 $display = $entry['id']; // Default display is the ID
                 // Check common display fields
                 foreach (['name', 'title',  'text_name', 'text_title', 'meta_title' ,'text_meta_title','text_name'] as $field) {
                     if (!empty($entry[$field])) {
                         $display = $entry[$field];
                         break;
                     }
                 }
                 // Add the processed entry to all options
                 $allRelatedData[] = ['id' => $entry['id'], 'display' => $display];
             }
     
             // Fetch the related entry for the selected ID
             $result = \DB::table($tableName)->where('id', $id)->first();
     
             if ($result) {
                 $data = (array) $result; // Convert to array
                 // \Log::info("Data found: ", $data);
                 
                 // Fields to prioritize as display fields
                 $displayFields = ['name', 'title', 'text_name', 'text_title', 'meta_title' ,'text_meta_title','text_name'];
                 
                 // Find the first available display field value
                 foreach ($displayFields as $field) {
                     if (isset($data[$field]) && !empty($data[$field])) {
                         $GetData['display'] = $data[$field];
                         break;
                     }
                 }
     
                 // Merge all fields into the return structure
                //  $GetData = array_merge($GetData);
                 $GetData = array_merge($GetData, $data); // here send all data of the selected row
             } else {
                 // \Log::warning("No data found for ID: $id in table: $tableName");
             }
         } catch (\Exception $e) {
             // \Log::error("Error fetching relational data: " . $e->getMessage());
         }
         
         return ['selected' => $GetData, 'allOptions' => $allRelatedData ];
        }

        }