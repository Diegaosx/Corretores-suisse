<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use App\Models\Collections;
use App\Models\User;
use Illuminate\Support\Str; // For slug generation
use App\Traits\GetRelationalFieldDetail;
class CollectionMetaController extends Controller
{

    use GetRelationalFieldDetail; // Use the trait
    public $collection;
    public $model;
    public $collectionHandle;
    public function validate_collection($collectionHandle){
        $collectionHandle = Str::slug($collectionHandle, '_');
        if($collectionHandle=='user'){
            $model=new User;
            $collection = $model::firstOrFail();
        }else{
            $model=new Collections;
            $collection = $model::where('handle', $collectionHandle)->firstOrFail();
        }
        $this->collection=$collection;
        $this->model=$model;
        $this->collectionHandle=$collectionHandle;
    }
    public function getFields($collectionHandle)
    {
       
        try {
            $this->validate_collection($collectionHandle);
            // Retrieve the collection or throw a ModelNotFoundException
            // $collection = Collections::findOrFail($collectionId);
            // Define the meta table name
            $metaTableName = $this->collectionHandle . '_meta';  
            // Check if the meta table exists
            if (!Schema::hasTable($metaTableName)) {
                return response()->json(['error' => 'Meta table does not exist.'], 404);
            }   
            // Get the columns of the meta table
            $columns = Schema::getColumnListing($metaTableName);
            $fields = [];
            foreach ($columns as $column) {   
                // Set default value as empty string
                $fields[$column] = ''; 
                // Check if the field matches the "rel_*_col_*" pattern
                if (Str::startsWith($column, 'rel_') && Str::contains($column, '_col_') ) {
                    
                    // Extract the portion after "_col_"
                    $fieldParts = explode('_col_', $column);
                    if (count($fieldParts) > 1) {
                        $relatedReference = $fieldParts[1]; // Get the part after "_col_"
                    } else {
                        throw new \Exception('Invalid field format: missing "_col_".');
                    }
                    // Determine the related meta table
                    if ($relatedReference === 'users') {
                        $relatedMetaTable = 'users';
                    } else {
                        $relatedMetaTable = $relatedReference; // Use the extracted value as the table name
                    }
                    // Fetch details from the related meta table
                    // if (Schema::hasTable($relatedMetaTable)) {
                    //     $relatedMeta = \DB::table($relatedMetaTable)
                    //         ->where('id', $column)
                    //         ->first();
                    // }
                    
                    // Get display value
                    $displayData = $this->getRelationalFieldDetail($relatedMetaTable, $column);
                    // Assign relational data to the field
                    // dd($displayData );
                    $fields[$column] = [
                        // 'selected' => $displayData['selected'] ?? null,
                        'allOptions' => $displayData['allOptions'] ?? [],
                    ];
                }
            }
            // Fetch all collections
            $allCollections = Collections::all(['id', 'name']); // Adjust the fields as necessary
            
            // Map the collections to get the desired format
            $allCollectionsArray = $allCollections->map(function ($collection) {
                return [
                    'id' => $collection->id,
                    'name' => $collection->name,
                ];
            });
            // Return both collection details and fields in the response
            return response()->json([
                'collection' => $this->collection,
                'fields' => $fields,
                'allCollections' => $allCollectionsArray,
            ], 200);
        } catch (\Exception $e) {
            // Return a 404 error if the collection is not found
            return response()->json(['error' => 'Collection not found.'], 404);
        }
    }
    
    
    

    public function create_entry(Request $request, $collectionHandle)
    {
        // $validatedData = $request->input();
        $validatedData = $request->except(array_keys($request->allFiles())); // Exclude dynamic file fields
        $validatedData['created_at'] = now();  // Set created_at to the current date/time
        try {
            $this->validate_collection($collectionHandle);
            $validatedData['collection_id'] = $this->collection->id; 
            // $collection = Collections::findOrFail($collectionId);
            $metaTableName = $this->collection->handle . '_meta';
            if (!Schema::hasTable($metaTableName)) {
                return response()->json(['error' => 'Meta table does not exist.'], 404);
            }
            // Handle file uploads
            $filePaths = $this->handleFileUploads($request);
            $validatedData = array_merge($validatedData, $filePaths);
            DB::table($metaTableName)->insert($validatedData);
            return response()->json(['message' => 'Record added successfully!'], 201);
        } catch (QueryException $qe) {
            return response()->json(['error' => 'Database error: ' . $qe->getMessage()], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An unexpected error occurred: ' . $e->getMessage()], 500);
        }
    }


    public function fetch_entry_detail($collectionHandle, $id)
    {
        // $collectionHandle = Str::slug($collectionHandle, '_');
        try {
            // $collection = Collections::findOrFail($collectionId);
            $this->validate_collection($collectionHandle);
            $metaTableName = $this->collection->handle . '_meta';

            if (!Schema::hasTable($metaTableName)) {
                return response()->json(['error' => 'Meta table does not exist.'], 404);
            }

            $entry = DB::table($metaTableName)->find($id);

            if (!$entry) {
                return response()->json(['error' => 'Entry not found.'], 404);
            }
            ///

            // Process relational fields in metaData
            // foreach ($entry as &$entry) {   
                foreach ($entry as $field => $value) {             
                    // Check if the field matches the "rel_*_col_*" pattern
                    if (Str::startsWith($field, 'rel_') && Str::contains($field, '_col_') ) {
                        // Extract the portion after "_col_"
                        $fieldParts = explode('_col_', $field);
                        if (count($fieldParts) > 1) {
                            $relatedReference = $fieldParts[1]; // Get the part after "_col_"
                        } else {
                            throw new \Exception('Invalid field format: missing "_col_".');
                        }
                        // Determine the related meta table
                        if ($relatedReference === 'users') {
                            $relatedMetaTable = 'users';
                        } else {
                            $relatedMetaTable = $relatedReference; // Use the extracted value as the table name
                        }

                        // Fetch details from the related meta table
                        if (Schema::hasTable($relatedMetaTable)) {
                            $relatedMeta = \DB::table($relatedMetaTable)
                                ->where('id', $value)
                                ->first();
                        }
                        
                        // Get display value
                        $displayData = $this->getRelationalFieldDetail($relatedMetaTable, $value);
                        // Replace ID with both ID and display value
                        $entry->$field = $displayData;
                    }
                }
                // dd($relatedMeta );
            // } 

            return response()->json(['collection' => $this->collection,'entry' => $entry], 200);
        } catch (QueryException $qe) {
            return response()->json(['error' => 'Database error: ' . $qe->getMessage()], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An unexpected error occurred: ' . $e->getMessage()], 500);
        }
    }

    public function update(Request $request, $collectionHandle, $id)
    {
        // $collectionHandle = Str::slug($collectionHandle, '_');
        $validatedData = $request->except(array_keys($request->allFiles())); // Exclude dynamic file fields
        $validatedData['updated_at'] = now();  // Set updated_at to the current date/time
        // Remove 'id' from the validated data (if present) as it should not be updated manually
        unset($validatedData['ID']);
        try {
            $this->validate_collection($collectionHandle);
            // $collection = Collections::findOrFail($collectionId);
            // $collection = Collections::where('handle', $collectionHandle)->firstOrFail();
            $metaTableName = $this->collection->handle . '_meta';
            if (!Schema::hasTable($metaTableName)) {
                return response()->json(['error' => 'Meta table does not exist.'], 404);
            }
            $record = DB::table($metaTableName)->where('id', $id)->first();
            if (!$record) {
                return response()->json(['error' => 'Entry not found.'], 404);
            }
            // Handle file uploads
            $filePaths = $this->handleFileUploads($request);
            $validatedData = array_merge($validatedData, $filePaths);

            $updatedRows = DB::table($metaTableName)->where('id', $id)->update($validatedData);

            if ($updatedRows === 0) {
                return response()->json(['error' => 'No existing records are updated.'], 404);
            }

            return response()->json(['message' => 'Record updated successfully!'], 200);
        } catch (QueryException $qe) {
            return response()->json(['error' => 'Database error: ' . $qe->getMessage()], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An unexpected error occurred: ' . $e->getMessage()], 500);
        }
    }

    /**
 * Handle file uploads and return an array of file paths.
 *
 * @param \Illuminate\Http\Request $request
 * @param string $directory
 * @return array
 */
    private function handleFileUploads(Request $request, $directory = 'uploads')
    {
        $filePaths = [];

        foreach ($request->allFiles() as $fieldName => $file) {
            if ($file->isValid()) {
                $originalName = $file->getClientOriginalName();
                $uniqueName = time() . '_' . $originalName;
                $path = $file->storeAs($directory, $uniqueName, 'public'); // Store in 'public/uploads'
                $filePaths[$fieldName] = $path; // Save file path for database insertion
            }
        }

        return $filePaths;
    }

    public function destroy($collectionHandle, $id)
    {
        // $collectionHandle = Str::slug($collectionHandle, '_');
        try {
            $this->validate_collection($collectionHandle);
            // $collection = Collections::findOrFail($collectionId);
            // $collection = Collections::where('handle', $this->collectionHandle)->firstOrFail();
            $metaTableName = $this->collection->handle . '_meta';

            if (!Schema::hasTable($metaTableName)) {
                return response()->json(['error' => 'Meta table does not exist.'], 404);
            }
            // Find the record in the meta table
            $record = DB::table($metaTableName)->where('id', $id)->first();
            if($record){
                DB::table($metaTableName)->where('id', $id)->delete();
                return response()->json(['message' => 'Record deleted successfully!'], 200);
            }else{
                return response()->json(['message' => 'No Record Found!'], 200);
            }
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }



}
