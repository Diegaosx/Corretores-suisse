<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Collections extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'type',
        'status',
        'handle'
    ];

        /**
     * Relationship with the `fields` table.
     */

    
}

