<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    use HasFactory;

    protected $fillable = ['name'];

    /**
     * Relationship: Role has many users through the user_roles table.
     */
    public function users()
    {
        return $this->belongsToMany(User::class, 'user_roles');
    }
}
